<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>cems</title>
<?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
</head>
<style>

/* Large rounded green border */
hr.blueline {
  border: 10px solid #00004d;
  border-radius: 5px;
}

#bj
{
  font-size: 22px;
}
</style>



  <?php require 'utils/header.php'; ?>
  <hr class="blueline">
  <div class="col-md-12">
  
<h1>About Us</h1>

<p>  Our college Mission is to impart quality technical education and higher moral ethics associated with skilled training to suit the modern day technology with innovative concepts,so as to learn to lead the future with full confidence
                  .</p>

</div>
<hr class="blueline">
</body>

 <?php require 'utils/footer.php'; ?>

</html>